var searchData=
[
  ['saturation',['saturation',['../interface_p_h_light_state.html#a4bdbe191d7a3d3b192916d203017bace',1,'PHLightState']]],
  ['softwareupdate',['softwareUpdate',['../interface_p_h_bridge_configuration.html#a469cefd7afe646b0782bf629c1d9e877',1,'PHBridgeConfiguration']]],
  ['ssdpsocket',['ssdpSocket',['../interface_p_h_bridge_searching.html#a8a55e20e53fe1f3d41b8f0f34cd69126',1,'PHBridgeSearching']]],
  ['swversion',['swversion',['../interface_p_h_bridge_configuration.html#a5583f00750e16eba997c33d711f35254',1,'PHBridgeConfiguration']]]
];
