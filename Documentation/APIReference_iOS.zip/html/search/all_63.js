var searchData=
[
  ['calculatexy_3aformodel_3a',['calculateXY:forModel:',['../interface_p_h_utilities.html#a4ece92f38f8c5c6b3902759e17e26987',1,'PHUtilities']]],
  ['colorfromxy_3aformodel_3a',['colorFromXY:forModel:',['../interface_p_h_utilities.html#a7a8e24ada7e005a75e23826ddf0a1aa0',1,'PHUtilities']]],
  ['colormode',['colormode',['../interface_p_h_light_state.html#a41c368abd615352c22d3cc066db39cfb',1,'PHLightState']]],
  ['connectslocal',['connectsLocal',['../interface_p_h_hue_s_d_k.html#ab12b821e39835d69e5145f43c0a66aac',1,'PHHueSDK']]],
  ['ct',['ct',['../interface_p_h_light_state.html#acbcfe68ed61a2b200a7677d61e54884e',1,'PHLightState']]]
];
