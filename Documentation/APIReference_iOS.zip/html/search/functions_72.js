var searchData=
[
  ['readbridgeresourcescache',['readBridgeResourcesCache',['../interface_p_h_bridge_resources_reader.html#a6a62cc09de50e7c7fbfb899e1a06ec81',1,'PHBridgeResourcesReader']]],
  ['registerobject_3awithselector_3afornotification_3a',['registerObject:withSelector:forNotification:',['../interface_p_h_notification_manager.html#a3cbab6dcf5acc4a2aa4cec83f3786357',1,'PHNotificationManager']]]
];
