var searchData=
[
  ['effect',['effect',['../interface_p_h_light_state.html#a2109fd1a2fd5c64d14a2bf995877d4eb',1,'PHLightState']]]
];
