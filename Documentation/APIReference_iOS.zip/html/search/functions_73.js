var searchData=
[
  ['sendnotification_3a',['sendNotification:',['../interface_p_h_notification_manager.html#ab6fa33780f90d7108fd857ac6296ad02',1,'PHNotificationManager']]],
  ['sendnotification_3awithuserinfo_3a',['sendNotification:withUserInfo:',['../interface_p_h_notification_manager.html#a6594165e1e24e1ea8ce51bdbb3f30f67',1,'PHNotificationManager']]],
  ['setbridgetousewithipaddress_3amacaddress_3a',['setBridgeToUseWithIpAddress:macAddress:',['../interface_p_h_hue_s_d_k.html#ae78156fa4b1d7c60b51a9835f2d335e7',1,'PHHueSDK']]],
  ['setbridgetousewithipaddress_3amacaddress_3aandusername_3a',['setBridgeToUseWithIpAddress:macAddress:andUsername:',['../interface_p_h_hue_s_d_k.html#a426f36afad0b301d060a01e3db5cfb12',1,'PHHueSDK']]],
  ['setonbool_3a',['setOnBool:',['../interface_p_h_light_state.html#a48c3313f3656c773c5ae82fffcdfe8d4',1,'PHLightState']]],
  ['startpushlinkauthentication',['startPushlinkAuthentication',['../interface_p_h_hue_s_d_k.html#a479520192882d4c21c51ccbceb856409',1,'PHHueSDK']]],
  ['startsearchwithcompletionhandler_3a',['startSearchWithCompletionHandler:',['../interface_p_h_bridge_searching.html#ab16474aa0db09a52960d40c4134584c5',1,'PHBridgeSearching']]],
  ['startupsdk',['startUpSDK',['../interface_p_h_hue_s_d_k.html#a71f7e7dbc980c4bb1e08e394ec06cd29',1,'PHHueSDK']]],
  ['stopsdk',['stopSDK',['../interface_p_h_hue_s_d_k.html#aeda278cc0776fd9ca5692913113b3f6d',1,'PHHueSDK']]]
];
