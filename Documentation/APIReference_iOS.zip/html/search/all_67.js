var searchData=
[
  ['gateway',['gateway',['../interface_p_h_bridge_configuration.html#a86cc3592283e6485c9f51c79eee9e5a9',1,'PHBridgeConfiguration']]],
  ['getbridgetimeasnsdate',['getBridgeTimeAsNSDate',['../interface_p_h_bridge_configuration.html#abad9b8c7ccab5945a00cb86d4d0695a3',1,'PHBridgeConfiguration']]],
  ['getlightstateasdictionary',['getLightStateAsDictionary',['../interface_p_h_light_state.html#a64d9aedd8403fdfc82b3a91e8fb7dab7',1,'PHLightState']]]
];
