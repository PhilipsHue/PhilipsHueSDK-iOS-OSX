var searchData=
[
  ['colormode',['colormode',['../interface_p_h_light_state.html#a41c368abd615352c22d3cc066db39cfb',1,'PHLightState']]],
  ['ct',['ct',['../interface_p_h_light_state.html#acbcfe68ed61a2b200a7677d61e54884e',1,'PHLightState']]]
];
