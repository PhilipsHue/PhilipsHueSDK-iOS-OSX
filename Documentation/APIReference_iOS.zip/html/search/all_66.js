var searchData=
[
  ['firstlocalheartbeatcompletedafterstart',['firstLocalHeartbeatCompletedAfterStart',['../interface_p_h_hue_s_d_k.html#a6b7b258eefa1409b99c4709af0266780',1,'PHHueSDK']]]
];
