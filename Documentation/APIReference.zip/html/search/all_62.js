var searchData=
[
  ['bridgeconfigurationasdictionary',['bridgeConfigurationAsDictionary',['../interface_p_h_bridge_configuration.html#a0be75a7bafcf5ec5bc327df11639e159',1,'PHBridgeConfiguration']]],
  ['bridgeid',['bridgeId',['../interface_p_h_bridge_configuration.html#a64cf9ecf7fd36856fd9dfa18498e58e4',1,'PHBridgeConfiguration']]],
  ['bridgesendapi',['bridgeSendAPI',['../interface_p_h_overall_factory.html#ae994d96c999b054db1cddc1b96edd326',1,'PHOverallFactory']]],
  ['brightness',['brightness',['../interface_p_h_light_state.html#a7d1d3e0ce718dbdd6547eeed6b1a95df',1,'PHLightState']]]
];
