var searchData=
[
  ['name',['name',['../interface_p_h_bridge_configuration.html#a14326e15423ac944bfb4fefece7dea46',1,'PHBridgeConfiguration::name()'],['../interface_p_h_bridge_resource.html#aa94363d732dd936f60452371e9c51445',1,'PHBridgeResource::name()']]],
  ['netmask',['netmask',['../interface_p_h_bridge_configuration.html#a5d90756a173d7a80c06a80d67af4c16a',1,'PHBridgeConfiguration']]],
  ['notificationmanager',['notificationManager',['../interface_p_h_hue_s_d_k.html#a3d5eac46033a1fb545e4263a4f71b9b6',1,'PHHueSDK']]]
];
