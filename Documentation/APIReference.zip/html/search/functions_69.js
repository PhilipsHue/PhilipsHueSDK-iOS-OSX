var searchData=
[
  ['initwithupnpsearch_3aandportalsearch_3a',['initWithUpnpSearch:andPortalSearch:',['../interface_p_h_bridge_searching.html#a17daa16c04d6d0fd7400534c7249eb98',1,'PHBridgeSearching']]],
  ['isvalid_3a',['isValid:',['../interface_p_h_bridge_resources_cache.html#ae790d93ec90d4d6af34cb3b9cfc9a9ae',1,'PHBridgeResourcesCache']]]
];
