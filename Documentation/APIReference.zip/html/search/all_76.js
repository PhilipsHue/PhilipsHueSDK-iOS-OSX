var searchData=
[
  ['validatelightstate',['validateLightState',['../interface_p_h_light_state.html#a6162042b45b3f971f3bce4afc961381f',1,'PHLightState']]]
];
