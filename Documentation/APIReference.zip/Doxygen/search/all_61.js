var searchData=
[
  ['alert',['alert',['../interface_p_h_light_state.html#aea60b7ed8dc13f3296eac0e81759f58f',1,'PHLightState']]]
];
