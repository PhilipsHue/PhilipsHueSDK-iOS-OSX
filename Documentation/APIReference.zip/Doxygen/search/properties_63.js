var searchData=
[
  ['colormodenumber',['colormodeNumber',['../interface_p_h_light_state.html#a11bf9a36d972b18cf252cca63e3fee0e',1,'PHLightState']]],
  ['ct',['ct',['../interface_p_h_light_state.html#acbcfe68ed61a2b200a7677d61e54884e',1,'PHLightState']]]
];
