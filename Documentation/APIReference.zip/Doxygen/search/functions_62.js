var searchData=
[
  ['bridgesendapi',['bridgeSendAPI',['../interface_p_h_overall_factory.html#ae994d96c999b054db1cddc1b96edd326',1,'PHOverallFactory']]]
];
