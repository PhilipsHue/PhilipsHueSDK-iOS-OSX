var searchData=
[
  ['effect',['effect',['../interface_p_h_light_state.html#a261a9c4958cd75dd137f863f16e42dd1',1,'PHLightState']]]
];
