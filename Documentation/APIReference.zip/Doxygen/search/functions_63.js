var searchData=
[
  ['calculatexy_3aandbrightness_3afromcolor_3aformodel_3a',['calculateXY:andBrightness:fromColor:forModel:',['../interface_p_h_utilities.html#a33c9e0b7f936643052fd1e7ab6f3169a',1,'PHUtilities']]],
  ['colorfromxy_3aandbrightness_3aformodel_3a',['colorFromXY:andBrightness:forModel:',['../interface_p_h_utilities.html#a68c38ea3a3482d66a845955d1660c534',1,'PHUtilities']]],
  ['connectslocal',['connectsLocal',['../interface_p_h_hue_s_d_k.html#ab12b821e39835d69e5145f43c0a66aac',1,'PHHueSDK']]],
  ['creategroupwithname_3alightids_3acompletionhandler_3a',['createGroupWithName:lightIds:completionHandler:',['../protocol_p_h_bridge_send_a_p_i-p.html#a32b92375ccb3490d0b7117445edec3d0',1,'PHBridgeSendAPI-p']]],
  ['createschedule_3acompletionhandler_3a',['createSchedule:completionHandler:',['../protocol_p_h_bridge_send_a_p_i-p.html#a648908a653d584af3b1b8b69e26d930f',1,'PHBridgeSendAPI-p']]]
];
