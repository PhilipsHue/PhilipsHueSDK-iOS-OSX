var searchData=
[
  ['gateway',['gateway',['../interface_p_h_bridge_configuration.html#a86cc3592283e6485c9f51c79eee9e5a9',1,'PHBridgeConfiguration']]],
  ['getbridgetimeasnsdate',['getBridgeTimeAsNSDate',['../interface_p_h_bridge_configuration.html#abad9b8c7ccab5945a00cb86d4d0695a3',1,'PHBridgeConfiguration']]],
  ['getgroupasdictionary',['getGroupAsDictionary',['../interface_p_h_group.html#ae03d703d531ec913a7ae313afffbf430',1,'PHGroup']]],
  ['getlightasdictionary',['getLightAsDictionary',['../interface_p_h_light.html#a2bd1409883dc3b1726a13006f3ff7ced',1,'PHLight']]],
  ['getlightstateasdictionary',['getLightStateAsDictionary',['../interface_p_h_light_state.html#a64d9aedd8403fdfc82b3a91e8fb7dab7',1,'PHLightState']]],
  ['getnewfoundlights_3a',['getNewFoundLights:',['../protocol_p_h_bridge_send_a_p_i-p.html#a831855ed54a3482131bab622a771f3f7',1,'PHBridgeSendAPI-p']]],
  ['getscheduleasdictionary',['getScheduleAsDictionary',['../interface_p_h_schedule.html#a33a1780ebc1d8831e48c761b616dbfca',1,'PHSchedule']]],
  ['getsoftwareupdatestatus_3a',['getSoftwareUpdateStatus:',['../protocol_p_h_bridge_send_a_p_i-p.html#a2e168fc1adf4bd87ac38e466078ed464',1,'PHBridgeSendAPI-p']]],
  ['groupidentifier',['groupIdentifier',['../interface_p_h_schedule.html#a59d623bad1d25f0be626caa5e8024767',1,'PHSchedule']]]
];
