var searchData=
[
  ['effect',['effect',['../interface_p_h_light_state.html#a2109fd1a2fd5c64d14a2bf995877d4eb',1,'PHLightState']]],
  ['enablelocalconnectionusinginterval_3a',['enableLocalConnectionUsingInterval:',['../interface_p_h_hue_s_d_k.html#a79d13599f1baf59731231d0b4aded4af',1,'PHHueSDK']]],
  ['enablelogging_3a',['enableLogging:',['../interface_p_h_hue_s_d_k.html#ae498d2438eef977d03ec54b77d57ef94',1,'PHHueSDK']]]
];
