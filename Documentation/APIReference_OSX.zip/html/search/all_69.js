var searchData=
[
  ['identifier',['identifier',['../interface_p_h_bridge_resource.html#ab5076b408588699360246b0e3a0bb903',1,'PHBridgeResource']]],
  ['initwithupnpsearch_3aandportalsearch_3a',['initWithUpnpSearch:andPortalSearch:',['../interface_p_h_bridge_searching.html#a2e21c76fa49e800fb884fc054110415e',1,'PHBridgeSearching']]],
  ['initwithupnpsearch_3aandportalsearch_3aandipadresssearch_3a',['initWithUpnpSearch:andPortalSearch:andIpAdressSearch:',['../interface_p_h_bridge_searching.html#af1fd915abf21f34e4c11ee91cf376cc8',1,'PHBridgeSearching']]],
  ['ipaddress',['ipaddress',['../interface_p_h_bridge_configuration.html#a4b93a5319fee9eee295ea368744a8ba1',1,'PHBridgeConfiguration']]],
  ['isvalid_3a',['isValid:',['../interface_p_h_bridge_resources_cache.html#ae790d93ec90d4d6af34cb3b9cfc9a9ae',1,'PHBridgeResourcesCache']]]
];
